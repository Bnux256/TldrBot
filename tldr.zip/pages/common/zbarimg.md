# zbarimg

> Scan and decode bar codes from image file(s).
> More information: <http://zbar.sourceforge.net>.

- Process an image file:

`zbarimg {{image_file}}`
