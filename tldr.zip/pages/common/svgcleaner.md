# svgcleaner

> SVG optimizing utility.
> More information: <https://github.com/RazrFalcon/svgcleaner>.

- Optimize an SVG:

`svgcleaner {{input.svg}} {{output.svg}}`

- Optimize an SVG multiple times:

`svgcleaner --multipass {{input.svg}} {{output.svg}}`
