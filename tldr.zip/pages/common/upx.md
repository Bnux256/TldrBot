# upx

> Compress or decompress executables.
> More information: <https://upx.github.io>.

- Compress executable:

`upx {{file}}`

- Decompress executable:

`upx -d {{file}}`

- Detailed help:

`upx --help`
