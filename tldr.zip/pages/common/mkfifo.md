# mkfifo

> Makes FIFOs (named pipes).
> More information: <https://www.gnu.org/software/coreutils/mkfifo>.

- Create a named pipe at a given path:

`mkfifo {{path/to/pipe}}`
