# filecoordinationd

> Coordinates access to files by multiple processes (`NSFileCoordinator`, `NSFilePresenter`).
> It should not be invoked manually.

- Start the daemon:

`filecoordinationd`
