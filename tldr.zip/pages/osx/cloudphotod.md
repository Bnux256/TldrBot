# cloudphotod

> This synchronizes iCloud Photos.
> It should not be invoked manually.

- Start the daemon:

`cloudphotod`
