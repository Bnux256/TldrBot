# avbdeviced

> A service for managing Audio Video Bridging (AVB) devices.
> It should not be invoked manually.

- Start the daemon:

`avbdeviced`
