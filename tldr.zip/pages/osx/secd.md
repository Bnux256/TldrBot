# secd

> Controls access to and modification of keychain items.
> It should not be invoked manually.

- Start the daemon:

`secd`
