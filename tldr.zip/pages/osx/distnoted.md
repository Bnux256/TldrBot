# distnoted

> Provides distributed notification services.
> It should not be invoked manually.

- Start the daemon:

`distnoted`
