# bnepd

> A service that handles all Bluetooth network connections.
> It should not be invoked manually.

- Start the daemon:

`bnepd`
