# photolibraryd

> This handles all photo library requests.
> It should not be invoked manually.

- Start the daemon:

`photolibraryd`
